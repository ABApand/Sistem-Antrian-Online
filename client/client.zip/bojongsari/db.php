<?php
// Database configuration
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "antrian_bojongsari";

// Enable error reporting for debugging
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT); // Report errors and exceptions

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    // Return a more detailed error message
    die("Connection failed: " . $conn->connect_error);
}

// Optional: Set charset to UTF-8 for better character handling
$conn->set_charset("utf8");

?>
