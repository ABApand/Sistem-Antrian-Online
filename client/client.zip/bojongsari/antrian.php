<?php
session_start();

require 'db.php'; // Koneksi database

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Hapus semua data antrian untuk hari ini
    $tanggal_hari_ini = date('Y-m-d');
    $sql = "DELETE FROM antrian WHERE tanggal = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $tanggal_hari_ini);

    if ($stmt->execute()) {
        $message = "Antrian untuk hari ini telah berhasil di-reset.";
    } else {
        $message = "Terjadi kesalahan saat mereset antrian: " . $stmt->error;
    }
    $stmt->close();
}
require 'db.php'; // Pastikan db.php sudah benar

// Set timezone ke Asia/Jakarta
date_default_timezone_set('Asia/Jakarta');

// Aktifkan error reporting untuk debugging
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Ambil data dari tabel log_antrian
$search = isset($_GET['search']) ? $_GET['search'] : '';
$sql = "SELECT * FROM log_antrian";
if (!empty($search)) {
    $sql .= " WHERE nama LIKE ?";
}

if ($stmt = $conn->prepare($sql)) {
    if (!empty($search)) {
        $search_param = "%" . $search . "%";
        $stmt->bind_param("s", $search_param);
    }
    $stmt->execute();
    $result = $stmt->get_result();
} else {
    echo "Error menyiapkan query: " . $conn->error;
    exit;
}

// Query untuk menghitung jumlah kemunculan setiap nama
$sql_ranking_nama = "
    SELECT 
        nama,
        MAX(telepon) AS telepon, -- Menggunakan MAX untuk kolom non-agregasi
        COUNT(nama) AS jumlah_muncul 
    FROM 
        log_antrian 
    GROUP BY 
        nama 
    ORDER BY 
        jumlah_muncul DESC
    LIMIT 10";
 // Batasi ke 10 nama teratas (opsional)
$result_ranking_nama = $conn->query($sql_ranking_nama);

if (!$result_ranking_nama) {
    die("Error mendapatkan data: " . $conn->error);
}

if (isset($_GET['delete_id'])) {
    // Hapus data berdasarkan ID
    $delete_id = $_GET['delete_id'];
    $delete_sql = "DELETE FROM log_antrian WHERE id = ?";
    $delete_stmt = $conn->prepare($delete_sql);
    $delete_stmt->bind_param("i", $delete_id);
    if ($delete_stmt->execute()) {
        header("Location: {$_SERVER['PHP_SELF']}"); // Refresh halaman setelah penghapusan
        exit;
    } else {
        echo "Error menghapus data: " . $delete_stmt->error;
    }
}

if (isset($_POST['edit_id'])) {
    // Edit data
    $edit_id = $_POST['edit_id'];
    $edit_nama = $_POST['edit_nama'];
    $edit_telepon = $_POST['edit_telepon'];

    $update_sql = "UPDATE log_antrian SET nama = ?, telepon = ? WHERE id = ?";
    $update_stmt = $conn->prepare($update_sql);
    $update_stmt->bind_param("ssi", $edit_nama, $edit_telepon, $edit_id);
    if ($update_stmt->execute()) {
        header("Location: {$_SERVER['PHP_SELF']}"); // Refresh halaman setelah edit
        exit;
    } else {
        echo "Error memperbarui data: " . $update_stmt->error;
    }
}


// Check if form is submitted to update jam_reset
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['jam_reset'])) {
    $new_jam_reset = $_POST['jam_reset'];

    // Validate the input
    if (strtotime($new_jam_reset)) {
        // Update the jam_reset value in the database
        $sql_update = "UPDATE settings SET value = ? WHERE key_name = 'jam_reset'";
        
        if ($stmt = $conn->prepare($sql_update)) {
            $stmt->bind_param("s", $new_jam_reset);
            if ($stmt->execute()) {
                echo "Jam reset telah diperbarui!";
            } else {
                echo "Error memperbarui jam reset: " . $conn->error;
            }
            $stmt->close();
        } else {
            echo "Error: " . $conn->error;
        }
    } else {
        echo "Format jam tidak valid!";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Semua Data Antrian</title>
    <link rel="stylesheet" href="/antrian/asset/style.css"> <!-- Pastikan file CSS sudah ada -->
    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f0f8ff; /* Latar belakang biru muda */
            overflow-y: auto; /* Pastikan halaman dapat di-scroll */
        }
        .container {
            max-width: 1200px;
            margin: 20px auto;
            padding: 20px;
            background-color: #ffffff;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            overflow-x: auto; /* Tambahkan scroll horizontal untuk container */
        }
        .container table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            font-size: 0.95em;
            table-layout: auto; /* Agar kolom dapat menyesuaikan */
        }
        table thead tr {
            background-color: #007bff; /* Biru cerah */
            color: white;
            text-align: left;
        }
        table th, table td {
            padding: 12px;
            text-align: center;
            border: 1px solid #ddd;
            word-wrap: break-word; /* Membungkus teks agar tidak melewati batas */
        }
        table tbody tr:nth-child(even) {
            background-color: #e9f5ff; /* Biru sangat terang */
        }
        table tbody tr:hover {
            background-color: #d6eaff; /* Biru terang */
        }
        .footer {
            text-align: center;
            color: #555;
            font-size: 0.85em;
            margin-top: 20px;
        }
        /* Responsif untuk perangkat kecil */
        @media (max-width: 768px) {
            table th, table td {
                padding: 8px;
                font-size: 0.85em;
            }
        }
    </style>
</head>
<body>
    <div class="container">
    <form method="POST" action="antrian.php">
            <label for="jam_reset">Jam Reset (format HH:MM:SS):</label>
            <input type="time" id="jam_reset" name="jam_reset" required>
            <button type="submit">Update Jam Reset</button>
        </form>
        <h1>Ranking Nama Paling Sering Muncul</h1>
        <div style="overflow-x: auto;">
            <table>
                <thead>
                    <tr>
                        <th>Peringkat</th>
                        <th>Nama</th>
                        <th>Telepon</th>
                        <th>Jumlah Muncul</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($result_ranking_nama->num_rows > 0): ?>
                        <?php 
                        $rank = 1;
                        while ($row = $result_ranking_nama->fetch_assoc()): 
                        ?>
                            <tr>
                                <td><?= $rank++ ?></td>
                                <td><?= htmlspecialchars($row['nama']) ?></td>
                                <td><?= htmlspecialchars($row['telepon']) ?></td>
                                <td><?= htmlspecialchars($row['jumlah_muncul']) ?></td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="4">Tidak ada data yang ditemukan.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <h1>Data Log Antrian</h1>
        <div style="overflow-x: auto; max-height: 400px; overflow-y: scroll;">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nomor Antrian</th>
                        <th>Nama</th>
                        <th>Telepon</th>
                        <th>Tanggal</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($result->num_rows > 0): ?>
                        <?php while ($row = $result->fetch_assoc()): ?>
                            <tr>
                                <td><?= $row['id'] ?></td>
                                <td><?= $row['random_number'] ?></td>
                                <td><?= htmlspecialchars($row['nama']) ?></td>
                                <td><?= htmlspecialchars($row['telepon']) ?></td>
                                <td><?= $row['tanggal'] ?></td>
                                <td>
                                    <a href="?edit_id=<?= $row['id'] ?>">Edit</a> | 
                                    <a href="?delete_id=<?= $row['id'] ?>" onclick="return confirm('Yakin ingin menghapus data ini?')">Hapus</a>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="6" style="text-align: center;">Tidak ada data ditemukan.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>
