<?php
session_start();

if (isset($_POST['location'])) {
    $_SESSION['user_location'] = $_POST['location'];
    echo "Location set to " . $_POST['location'];
} else {
    echo "No location provided.";
}
?>
